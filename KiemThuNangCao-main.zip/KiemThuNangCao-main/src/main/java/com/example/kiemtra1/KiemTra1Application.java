package com.example.kiemtra1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KiemTra1Application {

	public static void main(String[] args) {
		SpringApplication.run(KiemTra1Application.class, args);
	}

}
